--Exploring the table 'train' by running select
Select * From train

--Exploring the top 10 rows from the table 'train'
Select top 10 * From train

