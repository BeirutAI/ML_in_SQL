--Lets explore the table [Statistics].Data_Describe_Numerical
Select * From [Statistics].Data_Describe_Numerical



