-------------------------------------------------------------------------------
--Drop columns from 'Wrangle.train' and 'Wrangle.train'
--Drop features Ticket and Cabin if exists by altering the tables and droping the column

alter table ______ drop ______ if exists ______
alter table ______ drop ______ if exists ______

alter table ______ drop ______ if exists ______
alter table ______ drop ______ if exists ______
