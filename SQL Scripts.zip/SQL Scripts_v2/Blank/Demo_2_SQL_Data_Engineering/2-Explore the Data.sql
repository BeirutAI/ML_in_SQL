-------------------------------------------------------------------------------
--Exploring the table 'train' by running select


--Exploring the top 10 rows from the table 'train'

