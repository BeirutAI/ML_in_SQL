-------------------------------------------------------------------------------
--# Drop column Parch,SibSp,FamilySize
alter table Wrangle.train drop column ______________
alter table Wrangle.test  drop column ______________

go

Select top 5 * From Wrangle.train