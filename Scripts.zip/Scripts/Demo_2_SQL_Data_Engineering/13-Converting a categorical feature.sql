-------------------------------------------------------------------------------
--Convert Female and Male to integer
--Explore Wrangle.train top 5 rows
Select
		_____
From Wrangle.train


---Update Wrangle.train and  Wrangle.test set Sex  = 1 when female and 0 when male
_______________________________________
_______________________________________

_______________________________________
_______________________________________

Select
		top 5 *
From Wrangle.[train]
