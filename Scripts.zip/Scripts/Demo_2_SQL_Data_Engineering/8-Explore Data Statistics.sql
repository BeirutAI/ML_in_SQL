-------------------------------------------------------------------------------
--Lets explore the table [Statistics].Data_Describe_Numerical
______________

